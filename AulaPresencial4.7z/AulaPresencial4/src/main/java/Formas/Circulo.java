package Formas;

import interfaces.Shape;

public class Circulo implements Shape {

	public void draw() {

		System.out.println("desenha um circulo");

	}

}

package Formas;

import interfaces.Shape;

public class Estrelinha implements Shape {

	public void draw() {
		System.out.println("desenha uma estrelinha");

	}

}

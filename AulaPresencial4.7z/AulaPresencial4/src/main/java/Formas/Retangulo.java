package Formas;

import interfaces.Shape;

public class Retangulo implements Shape {

	public void draw() {
		
		System.out.println("desenha um retangulo");

	}

}

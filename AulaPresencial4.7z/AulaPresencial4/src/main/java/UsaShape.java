import Formas.Circulo;
import Formas.Estrelinha;
import Formas.Retangulo;
import decorator.borda.RedShapeDecorator;
import decorator.preenchimento.RedFullShapeDecorator;

public class UsaShape {

	public static void main(String[] args) {
		
		/*Circulo circulo = new Circulo();
		circulo.draw();*/
		
		RedShapeDecorator redShape1 = new RedShapeDecorator(new Circulo());
		redShape1.draw();
		
		RedShapeDecorator redShape2 = new RedShapeDecorator(new Estrelinha());
		redShape2.draw();
		
		RedFullShapeDecorator redFulShape = new RedFullShapeDecorator(new Retangulo());
		redFulShape.draw();
		
	}

}

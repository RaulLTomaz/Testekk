package decorator.borda;

import decorator.ShapeDecorator;
import interfaces.Shape;

public class RedShapeDecorator extends ShapeDecorator {
	
	public RedShapeDecorator(Shape decorarShape) {
		super(decorarShape);
	}
	
	public void setRedBorder() {
		System.out.println("borda vermelha");
	}
	
	@Override
	public void draw() {
		decoratorShape.draw();
		setRedBorder();
	}

}

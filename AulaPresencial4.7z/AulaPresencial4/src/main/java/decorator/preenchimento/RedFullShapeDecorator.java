package decorator.preenchimento;

import decorator.ShapeDecorator;
import interfaces.Shape;

public class RedFullShapeDecorator extends ShapeDecorator implements Shape {
	
	public RedFullShapeDecorator(Shape decorarShape) {
		super(decorarShape);
	}
	
	public void setRedBackgrownd() {
		System.out.println("preenche de vermelho");
	}
	
	@Override
	public void draw() {
		decoratorShape.draw();
		setRedBackgrownd();
	}

}
